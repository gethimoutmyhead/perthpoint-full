<?php
/*****************************************************************************
 * WP Advanced Importer is a Tool for importing XML for the Wordpress
 * plugin developed by Smackcoders. Copyright (C) 2014 Smackcoders.
 *
 * WP Advanced Importer is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation with the addition of the
 * following permission added to Section 15 as permitted in Section 7(a): FOR
 * ANY PART OF THE COVERED WORK IN WHICH THE COPYRIGHT IS OWNED BY WP Advanced
 * Importer, WP Advanced Importer DISCLAIMS THE WARRANTY OF NON
 * INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * WP Advanced Importer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write
 * to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA.
 *
 * You can contact Smackcoders at email address info@smackcoders.com.
 *
 * The interactive user interfaces in original and modified versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * WP Advanced Importer copyright notice. If the display of the logo is
 * not reasonably feasible for technical reasons, the Appropriate Legal
 * Notices must display the words
 * "Copyright Smackcoders. 2015. All rights reserved".
 ********************************************************************************/

if ( ! defined( 'ABSPATH' ) )
        exit; // Exit if accessed directly

class ImporterLib {
	var $rzfejj_23 = true;
	var $lfxszn_24 = array();
	var $aerjwu_25 = null;
	var $huepva_26 = false;
	var $qnghcy_27 = null;
	var $nplcju_28 = ',';
	var $ezvruf_29 = '"';
	var $hhtsch_30 = null;
	var $rtkfzr_31 = null;
	var $urccim_32 = null;
	var $ppbenb_38 = 15;
	var $gpxabp_40 = "a-zA-Z0-9\n\r";
	var $qyllow_39 = ",;\t.:|";
	var $fybktu_41 = false;
	var $bmalcx_42 = 'ISO-8859-1';
	var $foevdt_43 = 'ISO-8859-1';
	var $bzcrxk_44 = "\r\n";
	var $huzgna_45 = ',';
        var $gbuviv_33 = 'data.csv';
	var $bhujwy_34 = false;
	var $iigiqu_63;
	var $nftvhw_20;
	var $jybluc_21 = 0;
	var $gtxpcj_22 = array();
	var $mpkaqs_35 = array();
	var $data = array();
	
	
	function akhrnw_2 ($dsmiub_46 = null, $rtkfzr_31 = null, $urccim_32 = null, $hhtsch_30 = null) {
		if ( $rtkfzr_31 !== null ) $this->rtkfzr_31 = $rtkfzr_31;
		if ( $urccim_32 !== null ) $this->urccim_32 = $urccim_32;
		if ( count($hhtsch_30) > 0 ) $this->hhtsch_30 = $hhtsch_30;
		if ( !empty($dsmiub_46) ) $this->ruscjv_15($dsmiub_46);
	}
	
	
	function ruscjv_15 ($dsmiub_46 = null, $rtkfzr_31 = null, $urccim_32 = null, $hhtsch_30 = null) {
		if ( $dsmiub_46 === null ) $dsmiub_46 = $this->iigiqu_63;
		if ( !empty($dsmiub_46) ) {
			if ( $rtkfzr_31 !== null ) $this->rtkfzr_31 = $rtkfzr_31;
			if ( $urccim_32 !== null ) $this->urccim_32 = $urccim_32;
			if ( count($hhtsch_30) > 0 ) $this->hhtsch_30 = $hhtsch_30;
			if ( is_readable($dsmiub_46) ) {
				$this->data = $this->ghloqy_7($dsmiub_46);
			} else {
				$this->nftvhw_20 = &$dsmiub_46;
				$this->data = $this->ytcfme_6();
			}
			if ( $this->data === false ) return false;
		}
		return true;
	}
	
	function vsxpii_16 ($iigiqu_63 = null, $huzgna_45 = array(), $bkarne_52 = false, $lfxszn_24 = array()) {
		if ( empty($iigiqu_63) ) $iigiqu_63 = &$this->iigiqu_63;
		$mode = ( $bkarne_52 ) ? 'at' : 'wt' ;
		$is_php = ( preg_match('/\.php$/i', $iigiqu_63) ) ? true : false ;
		return $this->jvyhik_14($iigiqu_63, $this->krlkbv_0($huzgna_45, $lfxszn_24, $bkarne_52, $is_php), $mode);
	}
	
	function wmyuyn_3 ($filename = null, $huzgna_45 = array(), $lfxszn_24 = array(), $delimiter = null) {
		if ( empty($filename) ) $filename = $this->gbuviv_33;
		if ( $delimiter === null ) $delimiter = $this->huzgna_45;
		$huzgna_45 = $this->krlkbv_0($huzgna_45, $lfxszn_24, null, null, $delimiter);
		if ( $filename !== null ) {
			header('Content-type: application/csv');
			header('Content-Disposition: attachment; filename="'.$filename.'"');
			echo $huzgna_45;
		}
		return $huzgna_45;
	}
	
	function fidfvc_4 ($dsmiub_46 = null, $wmrey_p8 = null) {
		$this->fybktu_41 = true;
		if ( $dsmiub_46 !== null ) $this->bmalcx_42 = $dsmiub_46;
		if ( $wmrey_p8 !== null ) $this->foevdt_43 = $wmrey_p8;
	}
	
	function delim ($iigiqu_63 = null, $parse = true, $search_depth = null, $preferred = null, $ezvruf_29 = null) {
		
		if ( $iigiqu_63 === null ) $iigiqu_63 = $this->iigiqu_63;
		if ( empty($search_depth) ) $search_depth = $this->ppbenb_38;
		if ( $ezvruf_29 === null ) $ezvruf_29 = $this->ezvruf_29;
		
		if ( $preferred === null ) $preferred = $this->qyllow_39;
		
		if ( empty($this->nftvhw_20) ) {
			if ( $this->totraw_9($iigiqu_63) ) {
				$huzgna_45 = &$this->nftvhw_20;
			} else return false;
		} else {
			$huzgna_45 = &$this->nftvhw_20;
		}
		
		$chars = array();
		$strlen = strlen($huzgna_45);
		$fqlsha_68 = false;
		$n = 1;
		$to_end = true;
		
		for ( $i=0; $i < $strlen; $i++ ) {
			$ch = $huzgna_45{$i};
			$nch = ( isset($huzgna_45{$i+1}) ) ? $huzgna_45{$i+1} : false ;
			$pch = ( isset($huzgna_45{$i-1}) ) ? $huzgna_45{$i-1} : false ;
			
			if ( $ch == $ezvruf_29 ) {
				if ( !$fqlsha_68 || $nch != $ezvruf_29 ) {
					$fqlsha_68 = ( $fqlsha_68 ) ? false : true ;
				} elseif ( $fqlsha_68 ) {
					$i++;
				}
				
			} elseif ( ($ch == "\n" && $pch != "\r" || $ch == "\r") && !$fqlsha_68 ) {
				if ( $n >= $search_depth ) {
					$strlen = 0;
					$to_end = false;
				} else {
					$n++;
				}
				
			} elseif (!$fqlsha_68) {
				if ( !preg_match('/['.preg_quote($this->gpxabp_40, '/').']/i', $ch) ) {
					if ( !isset($chars[$ch][$n]) ) {
						$chars[$ch][$n] = 1;
					} else {
						$chars[$ch][$n]++;
					}
				}
			}
		}
		
		$depth = ( $to_end ) ? $n-1 : $n ;
		$filtered = array();
		foreach( $chars as $char => $value ) {
			if ( $match = $this->klpqct_10($char, $value, $depth, $preferred) ) {
				$filtered[$match] = $char;
			}
		}
		
		ksort($filtered);
		$this->delimiter = reset($filtered);
		
		if ( $parse ) $this->data = $this->ytcfme_6();
		
		return $this->delimiter;
		
	}
	
	
	function vh100 ($iigiqu_63 = null) {
		if ( $iigiqu_63 === null ) $iigiqu_63 = $this->iigiqu_63;
		if ( empty($this->nftvhw_20) ) $this->fmilrp_13($iigiqu_63);
		return ( !empty($this->nftvhw_20) ) ? $this->ytcfme_6() : false ;
	}
	
	function ytcfme_6 ($huzgna_45 = null) {
		if ( empty($huzgna_45) ) {
			if ( $this->totraw_9() ) {
				$huzgna_45 = &$this->nftvhw_20;
			} else return false;
		}
		
		$white_spaces = str_replace($this->delimiter, '', " \t\x0B\0");
		
		$jlesjs_83 = array();
		$mbswxn_84 = array();
		$cdgpzw_85 = 0;
		$ewhrie_86 = '';
		$head = ( !empty($this->lfxszn_24) ) ? $this->lfxszn_24 : array() ;
		$eylwks_89 = 0;
		$fqlsha_68 = false;
		$qobixt_90 = false;
		$strlen = strlen($huzgna_45);
		
		for ( $i=0; $i < $strlen; $i++ ) {
			$ch = $huzgna_45{$i};
			$nch = ( isset($huzgna_45{$i+1}) ) ? $huzgna_45{$i+1} : false ;
			$pch = ( isset($huzgna_45{$i-1}) ) ? $huzgna_45{$i-1} : false ;
			
			if ( $ch == $this->ezvruf_29 ) {
				if ( !$fqlsha_68 ) {
					if ( ltrim($ewhrie_86, $white_spaces) == '' ) {
						$fqlsha_68 = true;
						$qobixt_90 = true;
					} else {
						$this->jybluc_21 = 2;
						$error_row = count($jlesjs_83) + 1;
						$error_col = $eylwks_89 + 1;
						if ( !isset($this->gtxpcj_22[$error_row.'-'.$error_col]) ) {
							$this->gtxpcj_22[$error_row.'-'.$error_col] = array(
								'type' => 2,
								'info' => 'Syntax error found on row '.$error_row.'. Non-enclosed lfxszn_24 can not contain double-quotes.',
								'row' => $error_row,
								'field' => $error_col,
								'field_name' => (!empty($head[$eylwks_89])) ? $head[$eylwks_89] : null,
							);
						}
						$ewhrie_86 .= $ch;
					}
				} elseif ($nch == $this->ezvruf_29) {
					$ewhrie_86 .= $ch;
					$i++;
				} elseif ( $nch != $this->delimiter && $nch != "\r" && $nch != "\n" ) {
					for ( $x=($i+1); isset($huzgna_45{$x}) && ltrim($huzgna_45{$x}, $white_spaces) == ''; $x++ ) {}
					if ( $huzgna_45{$x} == $this->delimiter ) {
						$fqlsha_68 = false;
						$i = $x;
					} else {
						if ( $this->jybluc_21 < 1 ) {
							$this->jybluc_21 = 1;
						}
						$error_row = count($jlesjs_83) + 1;
						$error_col = $eylwks_89 + 1;
						if ( !isset($this->gtxpcj_22[$error_row.'-'.$error_col]) ) {
							$this->gtxpcj_22[$error_row.'-'.$error_col] = array(
								'type' => 1,
								'info' =>
									'Syntax error found on row '.(count($jlesjs_83) + 1).'. '.
									'A single double-quote was found within an enclosed string. '.
									'Enclosed double-quotes must be escaped with a second double-quote.',
								'row' => count($jlesjs_83) + 1,
								'field' => $eylwks_89 + 1,
								'field_name' => (!empty($head[$eylwks_89])) ? $head[$eylwks_89] : null,
							);
						}
						$ewhrie_86 .= $ch;
						$fqlsha_68 = false;
					}
				} else {
					$fqlsha_68 = false;
				}
				
			// end of field/row
			} elseif ( ($ch == $this->delimiter || $ch == "\n" || $ch == "\r") && !$fqlsha_68 ) {
				$key = ( !empty($head[$eylwks_89]) ) ? $head[$eylwks_89] : $eylwks_89 ;
				$mbswxn_84[$key] = ( $qobixt_90 ) ? $ewhrie_86 : trim($ewhrie_86) ;
				$ewhrie_86 = '';
				$qobixt_90 = false;
				$eylwks_89++;
				
				// end of row
				if ( $ch == "\n" || $ch == "\r" ) {
					if ( $this->blhlef_1($cdgpzw_85) && $this->qnoiuh_17s($mbswxn_84, $this->hhtsch_30) ) {
						if ( $this->rzfejj_23 && empty($head) ) {
							$head = $mbswxn_84;
						} elseif ( empty($this->lfxszn_24) || (!empty($this->lfxszn_24) && (($this->rzfejj_23 && $cdgpzw_85 > 0) || !$this->rzfejj_23)) ) {
							if ( !empty($this->aerjwu_25) && !empty($mbswxn_84[$this->aerjwu_25]) ) {
								if ( isset($jlesjs_83[$mbswxn_84[$this->aerjwu_25]]) ) {
									$jlesjs_83[$mbswxn_84[$this->aerjwu_25].'_0'] = &$jlesjs_83[$mbswxn_84[$this->aerjwu_25]];
									unset($jlesjs_83[$mbswxn_84[$this->aerjwu_25]]);
									for ( $sn=1; isset($jlesjs_83[$mbswxn_84[$this->aerjwu_25].'_'.$sn]); $sn++ ) {}
									$jlesjs_83[$mbswxn_84[$this->aerjwu_25].'_'.$sn] = $mbswxn_84;
								} else $jlesjs_83[$mbswxn_84[$this->aerjwu_25]] = $mbswxn_84;
							} else $jlesjs_83[] = $mbswxn_84;
						}
					}
					$mbswxn_84 = array();
					$eylwks_89 = 0;
					$cdgpzw_85++;
					if ( $this->aerjwu_25 === null && $this->urccim_32 !== null && count($jlesjs_83) == $this->urccim_32 ) {
						$i = $strlen;
					}
					if ( $ch == "\r" && $nch == "\n" ) $i++;
				}
				
			} else {
				$ewhrie_86 .= $ch;
			}
		}
		$this->mpkaqs_35 = $head;
		if ( !empty($this->aerjwu_25) ) {
			$qnghcy_27 = SORT_REGULAR;
			if ( $this->qnghcy_27 == 'numeric' ) {
				$qnghcy_27 = SORT_NUMERIC;
			} elseif ( $this->qnghcy_27 == 'string' ) {
				$qnghcy_27 = SORT_STRING;
			}
			( $this->huepva_26 ) ? krsort($jlesjs_83, $qnghcy_27) : ksort($jlesjs_83, $qnghcy_27) ;
			if ( $this->rtkfzr_31 !== null || $this->urccim_32 !== null ) {
				$jlesjs_83 = array_slice($jlesjs_83, ($this->rtkfzr_31 === null ? 0 : $this->rtkfzr_31) , $this->urccim_32, true);
			}
		}
		if ( !$this->bhujwy_34 ) {
			$this->nftvhw_20 = null;
		}
		return $jlesjs_83;
	}
	
	function krlkbv_0 ( $huzgna_45 = array(), $lfxszn_24 = array(), $bkarne_52 = false , $is_php = false, $delimiter = null) {
		if ( !is_array($huzgna_45) || empty($huzgna_45) ) $huzgna_45 = &$this->data;
		if ( !is_array($lfxszn_24) || empty($lfxszn_24) ) $lfxszn_24 = &$this->mpkaqs_35;
		if ( $delimiter === null ) $delimiter = $this->delimiter;
		
		$string = ( $is_php ) ? "<?php header('Status: 403'); die(' '); ?>".$this->bzcrxk_44 : '' ;
		$entry = array();
		
		if ( $this->rzfejj_23 && !$bkarne_52 && !empty($lfxszn_24) ) {
			foreach( $lfxszn_24 as $key => $value ) {
				$entry[] = $this->sxzpwt_8($value);
			}
			$string .= implode($delimiter, $entry).$this->bzcrxk_44;
			$entry = array();
		}
		
		foreach( $huzgna_45 as $key => $mbswxn_84 ) {
			foreach( $mbswxn_84 as $field => $value ) {
				$entry[] = $this->sxzpwt_8($value);
			}
			$string .= implode($delimiter, $entry).$this->bzcrxk_44;
			$entry = array();
		}
		
		return $string;
	}
	
	function fmilrp_13 ($dsmiub_46 = null) {
		$huzgna_45 = null;
		$iigiqu_63 = null;
		if ( $dsmiub_46 === null ) {
			$iigiqu_63 = $this->iigiqu_63;
		} elseif ( file_exists($dsmiub_46) ) {
			$iigiqu_63 = $dsmiub_46;
		} else {
			$huzgna_45 = $dsmiub_46;
		}
		if ( !empty($huzgna_45) || $huzgna_45 = $this->rqauqn_12($iigiqu_63) ) {
			if ( $this->iigiqu_63 != $iigiqu_63 ) $this->iigiqu_63 = $iigiqu_63;
			if ( preg_match('/\.php$/i', $iigiqu_63) && preg_match('/<\?.*?\?>(.*)/ims', $huzgna_45, $strip) ) {
				$huzgna_45 = ltrim($strip[1]);
			}
			if ( $this->fybktu_41 ) $huzgna_45 = iconv($this->bmalcx_42, $this->foevdt_43, $huzgna_45);
			if ( substr($huzgna_45, -1) != "\n" ) $huzgna_45 .= "\n";
			$this->nftvhw_20 = &$huzgna_45;
			return true;
		}
		return false;
	}
	
	
	function qnoiuh_17s ($mbswxn_84 = array(), $hhtsch_30 = null) {
		if ( !empty($mbswxn_84) ) {
			if ( !empty($hhtsch_30) ) {
			$hhtsch_30 = (strpos($hhtsch_30, ' OR ') !== false) ? explode(' OR ', $hhtsch_30) : array($hhtsch_30);
				$or = '';
				foreach( $hhtsch_30 as $key => $value ) {
					if ( strpos($value, ' AND ') !== false ) {
						$value = explode(' AND ', $value);
						$and = '';
						foreach( $value as $k => $v ) {
							$and .= $this->qnoiuh_17($mbswxn_84, $v);
						}
						$or .= (strpos($and, '0') !== false) ? '0' : '1' ;
					} else {
						$or .= $this->qnoiuh_17($mbswxn_84, $value);
					}
				}
				return (strpos($or, '1') !== false) ? true : false ;
			}
			return true;
		}
		return false;
	}
	
	function qnoiuh_17 ($mbswxn_84, $condition) {
		$operators = array(
			'=', 'equals', 'is',
			'!=', 'is not',
			'<', 'is less than',
			'>', 'is greater than',
			'<=', 'is less than or equals',
			'>=', 'is greater than or equals',
			'contains',
			'does not contain',
		);
		$operators_regex = array();
		foreach( $operators as $value ) {
			$operators_regex[] = preg_quote($value, '/');
		}
		$operators_regex = implode('|', $operators_regex);
		if ( preg_match('/^(.+) ('.$operators_regex.') (.+)$/i', trim($condition), $capture) ) {
			$field = $capture[1];
			$op = $capture[2];
			$value = $capture[3];
			if ( preg_match('/^([\'\"]{1})(.*)([\'\"]{1})$/i', $value, $capture) ) {
				if ( $capture[1] == $capture[3] ) {
					$value = $capture[2];
					$value = str_replace("\\n", "\n", $value);
					$value = str_replace("\\r", "\r", $value);
					$value = str_replace("\\t", "\t", $value);
					$value = stripslashes($value);
				}
			}
			if ( array_key_exists($field, $mbswxn_84) ) {
				if ( ($op == '=' || $op == 'equals' || $op == 'is') && $mbswxn_84[$field] == $value ) {
					return '1';
				} elseif ( ($op == '!=' || $op == 'is not') && $mbswxn_84[$field] != $value ) {
					return '1';
				} elseif ( ($op == '<' || $op == 'is less than' ) && $mbswxn_84[$field] < $value ) {
					return '1';
				} elseif ( ($op == '>' || $op == 'is greater than') && $mbswxn_84[$field] > $value ) {
					return '1';
				} elseif ( ($op == '<=' || $op == 'is less than or equals' ) && $mbswxn_84[$field] <= $value ) {
					return '1';
				} elseif ( ($op == '>=' || $op == 'is greater than or equals') && $mbswxn_84[$field] >= $value ) {
					return '1';
				} elseif ( $op == 'contains' && preg_match('/'.preg_quote($value, '/').'/i', $mbswxn_84[$field]) ) {
					return '1';
				} elseif ( $op == 'does not contain' && !preg_match('/'.preg_quote($value, '/').'/i', $mbswxn_84[$field]) ) {
					return '1';
				} else {
					return '0';
				}
			}
		}
		return '1';
	}
	
	function blhlef_1 ($ewhrie_86_row) {
		if ( $this->aerjwu_25 === null && $this->rtkfzr_31 !== null && $ewhrie_86_row < $this->rtkfzr_31 ) return false;
		return true;
	}
	
	function sxzpwt_8 ($value = null) {
		if ( $value !== null && $value != '' ) {
			$delimiter = preg_quote($this->delimiter, '/');
			$ezvruf_29 = preg_quote($this->ezvruf_29, '/');
			if ( preg_match("/".$delimiter."|".$ezvruf_29."|\n|\r/i", $value) || ($value{0} == ' ' || substr($value, -1) == ' ') ) {
				$value = str_replace($this->ezvruf_29, $this->ezvruf_29.$this->ezvruf_29, $value);
				$value = $this->ezvruf_29.$value.$this->ezvruf_29;
			}
		}
		return $value;
	}
	
	function totraw_9 ($iigiqu_63 = null) {
		if ( empty($this->nftvhw_20) ) {
			if ( $iigiqu_63 === null ) $iigiqu_63 = $this->iigiqu_63;
			return $this->fmilrp_13($iigiqu_63);
		}
		return true;
	}
	
	
	function klpqct_10 ($char, $array, $depth, $preferred) {
		if ( $depth == count($array) ) {
			$first = null;
			$equal = null;
			$almost = false;
			foreach( $array as $key => $value ) {
				if ( $first == null ) {
					$first = $value;
				} elseif ( $value == $first && $equal !== false) {
					$equal = true;
				} elseif ( $value == $first+1 && $equal !== false ) {
					$equal = true;
					$almost = true;
				} else {
					$equal = false;
				}
			}
			if ( $equal ) {
				$match = ( $almost ) ? 2 : 1 ;
				$pref = strpos($preferred, $char);
				$pref = ( $pref !== false ) ? str_pad($pref, 3, '0', STR_PAD_LEFT) : '999' ;
				return $pref.$match.'.'.(99999 - str_pad($first, 5, '0', STR_PAD_LEFT));
			} else return false;
		}
	}
	
	function rqauqn_12 ($iigiqu_63 = null) {
		if ( is_readable($iigiqu_63) ) {
			if ( !($fh = fopen($iigiqu_63, 'r')) ) return false;
			$huzgna_45 = fread($fh, filesize($iigiqu_63));
			fclose($fh);
			return $huzgna_45;
		}
		return false;
	}

	function jvyhik_14 ($iigiqu_63, $string = '', $mode = 'wb', $lock = 2) {
		if ( $fp = fopen($iigiqu_63, $mode) ) {
			flock($fp, $lock);
			$re = fwrite($fp, $string);
			$re2 = fclose($fp);
			if ( $re != false && $re2 != false ) return true;
		}
		return false;
	}
	
}