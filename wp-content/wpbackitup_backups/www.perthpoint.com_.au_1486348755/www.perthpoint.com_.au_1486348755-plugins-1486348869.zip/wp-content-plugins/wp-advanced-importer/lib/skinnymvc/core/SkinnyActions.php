<?php
/******************************
 * filename:    SkinnyActions.php
 * description: main Actions class
 */

class SkinnyActions extends SkinnyBaseActions {

}

