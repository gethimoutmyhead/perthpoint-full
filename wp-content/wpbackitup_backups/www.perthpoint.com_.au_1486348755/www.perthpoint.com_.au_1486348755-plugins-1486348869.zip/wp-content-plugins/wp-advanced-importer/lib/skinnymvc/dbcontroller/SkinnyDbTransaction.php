<?php
/**
 * filename:    SkinnyDbTransaction.php
 * description: Database Transaction class
 */

class SkinnyDbTransaction extends SkinnyBaseDbTransaction {
}
