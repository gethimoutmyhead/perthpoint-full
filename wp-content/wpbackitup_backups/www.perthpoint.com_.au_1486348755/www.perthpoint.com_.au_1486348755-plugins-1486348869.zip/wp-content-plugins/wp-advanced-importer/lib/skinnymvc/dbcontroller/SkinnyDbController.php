<?php
/**
 * filename:    SkinnyDbController.php
 * description: Database controller
 */

class SkinnyDbController extends SkinnyBaseDbController {

}

    