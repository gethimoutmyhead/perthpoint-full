<?php
/******************************
 * filename:    SkinnyException.php
 * description: main Exception class
 */

class SkinnyException extends Exception {
}
    