<?php
/**
 * filename:    Model.php
 * description: Use this class for methods that you want to extend into all model classes.
 */

abstract class SkinnyModel extends SkinnyBaseModel {
}
    