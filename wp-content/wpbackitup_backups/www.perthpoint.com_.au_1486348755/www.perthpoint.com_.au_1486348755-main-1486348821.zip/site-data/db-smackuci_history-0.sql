-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : smackuci_history
-- Snapshot Table  : 1486348755x_smackuci_history
--
-- SQL    : SELECT * FROM smackuci_history LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755x_smackuci_history`
--
DROP TABLE  IF EXISTS `1486348755x_smackuci_history`;
CREATE TABLE `1486348755x_smackuci_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `time_taken` text COLLATE utf8mb4_unicode_520_ci,
  `date` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `summary` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `smackuci_history`
-- Number of rows: 0
--
--
-- Data for table `smackuci_history`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
