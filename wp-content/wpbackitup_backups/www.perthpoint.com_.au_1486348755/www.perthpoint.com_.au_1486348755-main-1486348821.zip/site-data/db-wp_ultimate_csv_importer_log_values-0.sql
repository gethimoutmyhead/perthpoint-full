-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:39
--
-- Database : perthpoi_db
--
-- Backup   Table  : wp_ultimate_csv_importer_log_values
-- Snapshot Table  : 1486348755x_wp_ultimate_csv_importer_log_values
--
-- SQL    : SELECT * FROM wp_ultimate_csv_importer_log_values LIMIT 0,10000
-- Offset : 0
-- Rows   : 53
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755x_wp_ultimate_csv_importer_log_values`
--
DROP TABLE  IF EXISTS `1486348755x_wp_ultimate_csv_importer_log_values`;
CREATE TABLE `1486348755x_wp_ultimate_csv_importer_log_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `eventKey` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `recordId` int(10) NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_of_import` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_message` blob NOT NULL,
  `imported_time` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `mode_of_import` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sequence` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `assigned_user_id` int(10) NOT NULL,
  `imported_by` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_ultimate_csv_importer_log_values`
-- Number of rows: 53
--
INSERT INTO `1486348755x_wp_ultimate_csv_importer_log_values` VALUES 
(1,'ab29a060d4a100bce03651e8610357a0',1103,'CustomPosts','','','','Insert','','',0,0),
 (2,'ab29a060d4a100bce03651e8610357a0',1104,'CustomPosts','','','','Insert','','',0,0),
 (3,'ab29a060d4a100bce03651e8610357a0',1105,'CustomPosts','','','','Insert','','',0,0),
 (4,'067cfd9ec34643348f7db0f114cc1fc4',1106,'CustomPosts','','','','Insert','','',0,0),
 (5,'dea80538e1a6e2649aad428fbab92775',1107,'CustomPosts','','','','Insert','','',0,0),
 (6,'12e5b1079076320dd06d49cb8660b521',1108,'CustomPosts','','','','Insert','','',0,0),
 (7,'12e5b1079076320dd06d49cb8660b521',1109,'CustomPosts','','','','Insert','','',0,0),
 (8,'12e5b1079076320dd06d49cb8660b521',1110,'CustomPosts','','','','Insert','','',0,0),
 (9,'c24135ca63f2f86d4025935044828511',1111,'CustomPosts','','','','Insert','','',0,0),
 (10,'82a11621f38f19164e6cdf2856ab24fe',1115,'CustomPosts','','','','Insert','','',0,0),
 (11,'82a11621f38f19164e6cdf2856ab24fe',1116,'CustomPosts','','','','Insert','','',0,0),
 (12,'82a11621f38f19164e6cdf2856ab24fe',1119,'CustomPosts','','','','Insert','','',0,0),
 (13,'e5b9415aa5c3e1b4a142a1aea5e37224',1142,'CustomPosts','','','','Insert','','',0,0),
 (14,'e5b9415aa5c3e1b4a142a1aea5e37224',1144,'CustomPosts','','','','Insert','','',0,0),
 (15,'e5b9415aa5c3e1b4a142a1aea5e37224',1146,'CustomPosts','','','','Insert','','',0,0),
 (16,'e5b9415aa5c3e1b4a142a1aea5e37224',1148,'CustomPosts','','','','Insert','','',0,0),
 (17,'7f7ca5bf9c227fe83d89a92844bbd732',1157,'CustomPosts','','','','Insert','','',0,0),
 (18,'7f7ca5bf9c227fe83d89a92844bbd732',1158,'CustomPosts','','','','Insert','','',0,0),
 (19,'7f7ca5bf9c227fe83d89a92844bbd732',1161,'CustomPosts','','','','Insert','','',0,0),
 (20,'7f7ca5bf9c227fe83d89a92844bbd732',1163,'CustomPosts','','','','Insert','','',0,0),
 (21,'7f7ca5bf9c227fe83d89a92844bbd732',1165,'CustomPosts','','','','Insert','','',0,0),
 (22,'7f7ca5bf9c227fe83d89a92844bbd732',1167,'CustomPosts','','','','Insert','','',0,0),
 (23,'7f7ca5bf9c227fe83d89a92844bbd732',1169,'CustomPosts','','','','Insert','','',0,0),
 (24,'0194fd84d9d901380b03820eb3ddc648',1171,'CustomPosts','','','','Insert','','',0,0),
 (25,'0194fd84d9d901380b03820eb3ddc648',1173,'CustomPosts','','','','Insert','','',0,0),
 (26,'902b0f32b8f199823963400f920bdbca',1175,'CustomPosts','','','','Insert','','',0,0),
 (27,'902b0f32b8f199823963400f920bdbca',1176,'CustomPosts','','','','Insert','','',0,0),
 (28,'902b0f32b8f199823963400f920bdbca',1179,'CustomPosts','','','','Insert','','',0,0),
 (29,'902b0f32b8f199823963400f920bdbca',1181,'CustomPosts','','','','Insert','','',0,0),
 (30,'fffaa6bbb655ad64c592fa37c27285d5',1183,'CustomPosts','','','','Insert','','',0,0),
 (31,'2034bf6b4cbe05296b69cab1561ff242',1185,'CustomPosts','','','','Insert','','',0,0),
 (32,'2034bf6b4cbe05296b69cab1561ff242',1186,'CustomPosts','','','','Insert','','',0,0),
 (33,'2034bf6b4cbe05296b69cab1561ff242',1189,'CustomPosts','','','','Insert','','',0,0),
 (34,'2034bf6b4cbe05296b69cab1561ff242',1191,'CustomPosts','','','','Insert','','',0,0),
 (35,'2034bf6b4cbe05296b69cab1561ff242',1193,'CustomPosts','','','','Insert','','',0,0),
 (36,'2034bf6b4cbe05296b69cab1561ff242',1195,'CustomPosts','','','','Insert','','',0,0),
 (37,'2034bf6b4cbe05296b69cab1561ff242',1197,'CustomPosts','','','','Insert','','',0,0),
 (38,'6c8400383d82bb9cc0ea7e0ed72c8354',1199,'CustomPosts','','','','Insert','','',0,0),
 (39,'6c8400383d82bb9cc0ea7e0ed72c8354',1200,'CustomPosts','','','','Insert','','',0,0),
 (40,'6c8400383d82bb9cc0ea7e0ed72c8354',1202,'CustomPosts','','','','Insert','','',0,0),
 (41,'6c8400383d82bb9cc0ea7e0ed72c8354',1204,'CustomPosts','','','','Insert','','',0,0),
 (42,'6c8400383d82bb9cc0ea7e0ed72c8354',1206,'CustomPosts','','','','Insert','','',0,0),
 (43,'6c8400383d82bb9cc0ea7e0ed72c8354',1208,'CustomPosts','','','','Insert','','',0,0),
 (44,'6c8400383d82bb9cc0ea7e0ed72c8354',1210,'CustomPosts','','','','Insert','','',0,0),
 (45,'5ed4b5d9d2b5130fba95c9f783342765',1293,'CustomPosts','','','','Insert','','',0,0),
 (46,'5ed4b5d9d2b5130fba95c9f783342765',1295,'CustomPosts','','','','Insert','','',0,0),
 (47,'5ed4b5d9d2b5130fba95c9f783342765',1296,'CustomPosts','','','','Insert','','',0,0),
 (48,'5ed4b5d9d2b5130fba95c9f783342765',1298,'CustomPosts','','','','Insert','','',0,0),
 (49,'fc8b360fe84ba2c872c2c612cc1f4e83',1300,'CustomPosts','','','','Insert','','',0,0),
 (50,'9e8158f9b72c2dba0ec099efb8e132ab',1302,'CustomPosts','','','','Insert','','',0,0),
 (51,'9e8158f9b72c2dba0ec099efb8e132ab',1304,'CustomPosts','','','','Insert','','',0,0),
 (52,'9e8158f9b72c2dba0ec099efb8e132ab',1305,'CustomPosts','','','','Insert','','',0,0),
 (53,'9e8158f9b72c2dba0ec099efb8e132ab',1306,'CustomPosts','','','','Insert','','',0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
