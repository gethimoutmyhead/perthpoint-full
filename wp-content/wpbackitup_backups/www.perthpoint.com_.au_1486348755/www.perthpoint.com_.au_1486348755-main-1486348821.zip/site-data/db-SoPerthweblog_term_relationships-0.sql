-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:39
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_term_relationships
-- Snapshot Table  : 1486348755_term_relationships
--
-- SQL    : SELECT * FROM SoPerthweblog_term_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 103
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_term_relationships`
--
DROP TABLE  IF EXISTS `1486348755_term_relationships`;
CREATE TABLE `1486348755_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_term_relationships`
-- Number of rows: 103
--
INSERT INTO `1486348755_term_relationships` VALUES 
(13,2,0),
 (25,3,0),
 (26,3,0),
 (27,3,0),
 (368,2,0),
 (372,2,0),
 (417,2,0),
 (484,2,0),
 (485,2,0),
 (498,2,0),
 (515,8,0),
 (536,2,0),
 (537,2,0),
 (538,2,0),
 (539,2,0),
 (540,2,0),
 (541,2,0),
 (542,2,0),
 (546,9,0),
 (547,9,0),
 (577,1,0),
 (594,6,0),
 (612,2,0),
 (613,6,0),
 (615,6,0),
 (616,6,0),
 (636,12,0),
 (638,12,0),
 (639,6,0),
 (646,12,0),
 (652,12,0),
 (658,6,0),
 (736,2,0),
 (749,6,0),
 (774,13,0),
 (777,13,0),
 (779,1,0),
 (798,13,0),
 (800,13,0),
 (801,8,0),
 (826,14,0),
 (855,14,0),
 (857,14,0),
 (861,6,0),
 (879,2,0),
 (882,6,0),
 (894,15,0),
 (895,14,0),
 (900,6,0),
 (919,14,0),
 (923,6,0),
 (935,2,0),
 (936,2,0),
 (939,2,0),
 (984,15,0),
 (986,15,0),
 (990,2,0),
 (993,16,0),
 (1001,6,0),
 (1023,6,0),
 (1036,6,0),
 (1038,6,0),
 (1051,6,0),
 (1055,6,0),
 (1064,16,0),
 (1066,16,0),
 (1076,16,0),
 (1078,15,0),
 (1082,16,0),
 (1088,16,0),
 (1091,16,0),
 (1096,16,0),
 (1098,16,0),
 (1126,14,0),
 (1128,14,0),
 (1130,14,0),
 (1142,15,0),
 (1144,15,0),
 (1146,15,0),
 (1155,16,0),
 (1157,15,0),
 (1158,15,0),
 (1161,15,0),
 (1163,13,0),
 (1165,15,0),
 (1167,15,0),
 (1169,15,0),
 (1185,15,0),
 (1186,15,0),
 (1189,15,0),
 (1191,15,0),
 (1193,15,0),
 (1195,15,0),
 (1197,15,0),
 (1199,13,0),
 (1200,15,0),
 (1202,13,0),
 (1206,15,0),
 (1208,15,0),
 (1210,12,0),
 (1220,16,0),
 (1228,14,0),
 (1231,14,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
