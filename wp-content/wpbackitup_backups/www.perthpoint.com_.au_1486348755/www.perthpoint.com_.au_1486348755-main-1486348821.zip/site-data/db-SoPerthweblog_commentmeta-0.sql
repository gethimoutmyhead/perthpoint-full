-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:39
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_commentmeta
-- Snapshot Table  : 1486348755_commentmeta
--
-- SQL    : SELECT * FROM SoPerthweblog_commentmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 62
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_commentmeta`
--
DROP TABLE  IF EXISTS `1486348755_commentmeta`;
CREATE TABLE `1486348755_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_commentmeta`
-- Number of rows: 62
--
INSERT INTO `1486348755_commentmeta` VALUES 
(13,9,'_wp_trash_meta_status','0'),
 (14,9,'_wp_trash_meta_time','1483714254'),
 (15,11,'_wp_trash_meta_status','0'),
 (16,11,'_wp_trash_meta_time','1483950244'),
 (17,13,'_wp_trash_meta_status','0'),
 (18,13,'_wp_trash_meta_time','1484038944'),
 (19,14,'_wp_trash_meta_status','0'),
 (20,14,'_wp_trash_meta_time','1484180615'),
 (21,16,'_wp_trash_meta_status','0'),
 (22,16,'_wp_trash_meta_time','1484357991'),
 (23,15,'_wp_trash_meta_status','0'),
 (24,15,'_wp_trash_meta_time','1484357995'),
 (25,17,'_wp_trash_meta_status','0'),
 (26,17,'_wp_trash_meta_time','1484398942'),
 (27,21,'_wp_trash_meta_status','0'),
 (28,21,'_wp_trash_meta_time','1484568400'),
 (29,20,'_wp_trash_meta_status','0'),
 (30,20,'_wp_trash_meta_time','1484568400'),
 (31,19,'_wp_trash_meta_status','0'),
 (32,19,'_wp_trash_meta_time','1484568400'),
 (33,18,'_wp_trash_meta_status','0'),
 (34,18,'_wp_trash_meta_time','1484568400'),
 (35,22,'_wp_trash_meta_status','0'),
 (36,22,'_wp_trash_meta_time','1484591376'),
 (37,26,'_wp_trash_meta_status','0'),
 (38,26,'_wp_trash_meta_time','1484729217'),
 (39,25,'_wp_trash_meta_status','0'),
 (40,25,'_wp_trash_meta_time','1484729217'),
 (41,24,'_wp_trash_meta_status','0'),
 (42,24,'_wp_trash_meta_time','1484729217'),
 (43,23,'_wp_trash_meta_status','0'),
 (44,23,'_wp_trash_meta_time','1484729217'),
 (45,29,'_wp_trash_meta_status','0'),
 (46,29,'_wp_trash_meta_time','1484833446'),
 (47,30,'_wp_trash_meta_status','0'),
 (48,30,'_wp_trash_meta_time','1484833446'),
 (49,28,'_wp_trash_meta_status','0'),
 (50,28,'_wp_trash_meta_time','1484833446'),
 (51,27,'_wp_trash_meta_status','0'),
 (52,27,'_wp_trash_meta_time','1484833446'),
 (53,32,'_wp_trash_meta_status','0'),
 (54,32,'_wp_trash_meta_time','1484915398'),
 (55,31,'_wp_trash_meta_status','0'),
 (56,31,'_wp_trash_meta_time','1484915398'),
 (57,35,'_wp_trash_meta_status','1'),
 (58,35,'_wp_trash_meta_time','1485178888'),
 (61,34,'_wp_trash_meta_status','0'),
 (62,34,'_wp_trash_meta_time','1485179273'),
 (63,37,'_wp_trash_meta_status','0'),
 (64,37,'_wp_trash_meta_time','1485859527'),
 (65,39,'_wp_trash_meta_status','0'),
 (66,39,'_wp_trash_meta_time','1486036797'),
 (67,38,'_wp_trash_meta_status','0'),
 (68,38,'_wp_trash_meta_time','1486036799'),
 (69,43,'_wp_trash_meta_status','0'),
 (70,43,'_wp_trash_meta_time','1486119961'),
 (71,42,'_wp_trash_meta_status','0'),
 (72,42,'_wp_trash_meta_time','1486119962'),
 (73,41,'_wp_trash_meta_status','0'),
 (74,41,'_wp_trash_meta_time','1486119964'),
 (75,40,'_wp_trash_meta_status','0'),
 (76,40,'_wp_trash_meta_time','1486119965');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
