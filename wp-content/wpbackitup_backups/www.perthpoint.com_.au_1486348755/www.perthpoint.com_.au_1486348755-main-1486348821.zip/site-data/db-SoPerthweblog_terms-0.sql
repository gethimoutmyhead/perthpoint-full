-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_terms
-- Snapshot Table  : 1486348755_terms
--
-- SQL    : SELECT * FROM SoPerthweblog_terms LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_terms`
--
DROP TABLE  IF EXISTS `1486348755_terms`;
CREATE TABLE `1486348755_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_terms`
-- Number of rows: 14
--
INSERT INTO `1486348755_terms` VALUES 
(1,'Uncategorized','uncategorized',0),
 (2,'Main Menu','main-menu',0),
 (3,'Major Events','major-events',0),
 (4,'Melbourne Cup 2016','melbourne-cup-2016',0),
 (5,'Halloween 2016','halloween-2016',0),
 (6,'New Years Eve 2016-17','new-years-eve-2016-17',0),
 (8,'Comedy','comedy',0),
 (9,'Dance','dance',0),
 (10,'Christmas and Boxing Day 2016','xmas-boxing-day-2016',0),
 (12,'Sunday-sesh','sunday-sesh',0),
 (13,'Quiz','quiz',0),
 (14,'music festival','music-festival',0),
 (15,'Happy Hour','happy-hour',0),
 (16,'Australia Day 2017','australia-day-2017',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
