-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : wp_ultimate_csv_importer_manageshortcodes
-- Snapshot Table  : 1486348755x_wp_ultimate_csv_importer_manageshortcodes
--
-- SQL    : SELECT * FROM wp_ultimate_csv_importer_manageshortcodes LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755x_wp_ultimate_csv_importer_manageshortcodes`
--
DROP TABLE  IF EXISTS `1486348755x_wp_ultimate_csv_importer_manageshortcodes`;
CREATE TABLE `1486348755x_wp_ultimate_csv_importer_manageshortcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pID` int(20) DEFAULT NULL,
  `shortcode` varchar(110) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `eventkey` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `mode_of_code` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `module` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `populate_status` int(5) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_ultimate_csv_importer_manageshortcodes`
-- Number of rows: 0
--
--
-- Data for table `wp_ultimate_csv_importer_manageshortcodes`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
