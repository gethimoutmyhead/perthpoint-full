-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:39
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_usermeta
-- Snapshot Table  : 1486348755_usermeta
--
-- SQL    : SELECT * FROM SoPerthweblog_usermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 73
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_usermeta`
--
DROP TABLE  IF EXISTS `1486348755_usermeta`;
CREATE TABLE `1486348755_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_usermeta`
-- Number of rows: 73
--
INSERT INTO `1486348755_usermeta` VALUES 
(1,1,'nickname','SoPerth_admin'),
 (2,1,'first_name',''),
 (3,1,'last_name',''),
 (4,1,'description',''),
 (5,1,'rich_editing','true'),
 (6,1,'comment_shortcuts','false'),
 (7,1,'admin_color','fresh'),
 (8,1,'use_ssl','0'),
 (9,1,'show_admin_bar_front','true'),
 (10,1,'SoPerthweblog_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
 (11,1,'SoPerthweblog_user_level','10'),
 (12,1,'dismissed_wp_pointers',''),
 (13,1,'show_welcome_panel','1'),
 (14,1,'session_tokens','a:3:{s:64:\"8f45532f11617fd8aa75ce5ac7ab460dcf67eda7ec2e616d7e789347c983778f\";a:4:{s:10:\"expiration\";i:1485390195;s:2:\"ip\";s:15:\"150.101.174.206\";s:2:\"ua\";s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0\";s:5:\"login\";i:1484180595;}s:64:\"bd12708fc9a105003740a6d26ae55d7e704d54264db266f3583e4422766ea149\";a:4:{s:10:\"expiration\";i:1485353344;s:2:\"ip\";s:12:\"175.38.99.48\";s:2:\"ua\";s:125:\"Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1\";s:5:\"login\";i:1485180544;}s:64:\"3c953cd14423a5e53c08f9b1ea333b4fc65182981908411e65cb128392a437d6\";a:4:{s:10:\"expiration\";i:1486464464;s:2:\"ip\";s:12:\"175.38.99.48\";s:2:\"ua\";s:125:\"Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1\";s:5:\"login\";i:1485254864;}}'),
 (15,1,'SoPerthweblog_dashboard_quick_press_last_post_id','1282'),
 (16,1,'SoPerthweblog_user-settings','libraryContent=browse&editor=tinymce&imgsize=mhmagazinelitecontent&cats=pop&hidetb=1'),
 (17,1,'SoPerthweblog_user-settings-time','1486289468'),
 (18,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
 (19,1,'metaboxhidden_nav-menus','a:1:{i:0;s:12:\"add-post_tag\";}'),
 (20,1,'nav_menu_recently_edited','2'),
 (21,1,'show_per_page','25'),
 (22,1,'orderby',''),
 (23,1,'meta-box-order__pods_template','a:3:{s:4:\"side\";s:23:\"submitdiv,pod_reference\";s:6:\"normal\";s:70:\"view_template,pods-meta-restrict-access,revisionsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
 (24,1,'screen_layout__pods_template','2'),
 (25,1,'closedpostboxes_post','a:0:{}'),
 (26,1,'metaboxhidden_post','a:6:{i:0;s:11:\"postexcerpt\";i:1;s:13:\"trackbacksdiv\";i:2;s:10:\"postcustom\";i:3;s:16:\"commentstatusdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}'),
 (27,2,'nickname','theperthpoint'),
 (28,2,'first_name','Perth'),
 (29,2,'last_name','Point'),
 (30,2,'description',''),
 (31,2,'rich_editing','true'),
 (32,2,'comment_shortcuts','false'),
 (33,2,'admin_color','fresh'),
 (34,2,'use_ssl','0'),
 (35,2,'show_admin_bar_front','true'),
 (36,2,'SoPerthweblog_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
 (37,2,'SoPerthweblog_user_level','10'),
 (38,2,'dismissed_wp_pointers',''),
 (39,1,'closedpostboxes_host','a:1:{i:0;s:11:\"commentsdiv\";}'),
 (40,1,'metaboxhidden_host','a:1:{i:0;s:7:\"slugdiv\";}'),
 (42,2,'SoPerthweblog_dashboard_quick_press_last_post_id','1263'),
 (43,2,'session_tokens','a:2:{s:64:\"503d5600d25b0e685c7eb9689c95950546f1ac11ba5a34c08875dad1e134f5dc\";a:4:{s:10:\"expiration\";i:1487051358;s:2:\"ip\";s:15:\"150.101.174.206\";s:2:\"ua\";s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0\";s:5:\"login\";i:1485841758;}s:64:\"ba86bed860bae572e8af4b1086b119d6dbf2eead885c58522db977d8db0ee3de\";a:4:{s:10:\"expiration\";i:1486465188;s:2:\"ip\";s:12:\"175.38.99.48\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_2) AppleWebKit/602.3.12 (KHTML, like Gecko) Version/10.0.2 Safari/602.3.12\";s:5:\"login\";i:1486292388;}}'),
 (44,2,'SoPerthweblog_user-settings','libraryContent=browse&hidetb=1&editor_plain_text_paste_warning=2&editor=tinymce'),
 (45,2,'SoPerthweblog_user-settings-time','1480644238'),
 (46,2,'nav_menu_recently_edited','2'),
 (47,2,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
 (48,2,'metaboxhidden_nav-menus','a:6:{i:0;s:23:\"add-post-type-dayofweek\";i:1;s:19:\"add-post-type-event\";i:2;s:18:\"add-post-type-host\";i:3;s:21:\"add-post-type-regular\";i:4;s:19:\"add-post-type-slide\";i:5;s:12:\"add-post_tag\";}'),
 (49,2,'show_per_page','25'),
 (50,2,'orderby',''),
 (51,1,'meta-box-order_dashboard','a:4:{s:6:\"normal\";s:93:\"dashboard_right_now,dashboard_activity,uci_pro_dashboard_linechart,uci_pro_dashboard_piechart\";s:4:\"side\";s:39:\"dashboard_quick_press,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}'),
 (52,2,'meta-box-order_event','a:3:{s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:46:\"slugdiv,pods-meta-more-fields,commentstatusdiv\";s:8:\"advanced\";s:0:\"\";}'),
 (53,2,'screen_layout_event','2'),
 (54,2,'closedpostboxes_event','a:0:{}'),
 (55,2,'metaboxhidden_event','a:1:{i:0;s:7:\"slugdiv\";}'),
 (56,2,'meta-box-order_host','a:3:{s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:29:\"slugdiv,pods-meta-more-fields\";s:8:\"advanced\";s:0:\"\";}'),
 (57,2,'screen_layout_host','2'),
 (58,2,'closedpostboxes_page','a:0:{}'),
 (59,2,'metaboxhidden_page','a:6:{i:0;s:12:\"revisionsdiv\";i:1;s:10:\"postcustom\";i:2;s:16:\"commentstatusdiv\";i:3;s:11:\"commentsdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}'),
 (60,1,'meta-box-order_event','a:3:{s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:58:\"slugdiv,pods-meta-more-fields,commentstatusdiv,commentsdiv\";s:8:\"advanced\";s:0:\"\";}'),
 (61,1,'screen_layout_event','2'),
 (62,2,'meta-box-order_dashboard','a:4:{s:6:\"normal\";s:38:\"dashboard_right_now,dashboard_activity\";s:4:\"side\";s:39:\"dashboard_quick_press,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}'),
 (63,1,'closedpostboxes__pods_template','a:0:{}'),
 (64,1,'metaboxhidden__pods_template','a:1:{i:0;s:7:\"slugdiv\";}'),
 (65,1,'closedpostboxes_event','a:0:{}'),
 (66,1,'metaboxhidden_event','a:1:{i:0;s:7:\"slugdiv\";}'),
 (67,1,'meta-box-order_host','a:3:{s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:58:\"commentsdiv,commentstatusdiv,slugdiv,pods-meta-more-fields\";s:8:\"advanced\";s:0:\"\";}'),
 (68,1,'screen_layout_host','2'),
 (69,2,'meta-box-order_slide','a:3:{s:4:\"side\";s:9:\"submitdiv\";s:6:\"normal\";s:29:\"slugdiv,pods-meta-more-fields\";s:8:\"advanced\";s:0:\"\";}'),
 (70,2,'screen_layout_slide','2'),
 (71,1,'closedpostboxes_dashboard','a:3:{i:0;s:27:\"uci_pro_dashboard_linechart\";i:1;s:26:\"uci_pro_dashboard_piechart\";i:2;s:17:\"dashboard_primary\";}'),
 (72,1,'metaboxhidden_dashboard','a:0:{}'),
 (73,2,'closedpostboxes_dashboard','a:0:{}'),
 (74,2,'metaboxhidden_dashboard','a:0:{}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
