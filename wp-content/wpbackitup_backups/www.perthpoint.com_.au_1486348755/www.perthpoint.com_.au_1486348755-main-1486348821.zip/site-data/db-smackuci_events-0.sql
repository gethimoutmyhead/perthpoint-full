-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:39
--
-- Database : perthpoi_db
--
-- Backup   Table  : smackuci_events
-- Snapshot Table  : 1486348755x_smackuci_events
--
-- SQL    : SELECT * FROM smackuci_events LIMIT 0,10000
-- Offset : 0
-- Rows   : 12
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755x_smackuci_events`
--
DROP TABLE  IF EXISTS `1486348755x_smackuci_events`;
CREATE TABLE `1486348755x_smackuci_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `revision` bigint(20) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `original_file_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `friendly_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `import_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `filetype` text COLLATE utf8mb4_unicode_520_ci,
  `filepath` text COLLATE utf8mb4_unicode_520_ci,
  `eventKey` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `registered_on` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `parent_node` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `executing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `event_started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `processed` bigint(20) NOT NULL DEFAULT '0',
  `created` bigint(20) NOT NULL DEFAULT '0',
  `updated` bigint(20) NOT NULL DEFAULT '0',
  `skipped` bigint(20) NOT NULL DEFAULT '0',
  `deleted` bigint(20) NOT NULL DEFAULT '0',
  `is_terminated` tinyint(1) NOT NULL DEFAULT '0',
  `terminated_on` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `last_activity` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `siteid` int(11) NOT NULL DEFAULT '1',
  `month` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `year` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `smackuci_events`
-- Number of rows: 12
--
INSERT INTO `1486348755x_smackuci_events` VALUES 
(1,5,'test-5.csv','test.csv',NULL,'regular','csv','/smack_uci_uploads/imports/12e5b1079076320dd06d49cb8660b521/12e5b1079076320dd06d49cb8660b521','12e5b1079076320dd06d49cb8660b521','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-09 03:49:19',3,3,3,0,0,0,0,'1970-01-02 00:00:01','2017-01-08 04:49:19',1,'Jan','2017'),
 (2,6,'test-6.csv','test.csv',NULL,'regular','csv','/smack_uci_uploads/imports/c24135ca63f2f86d4025935044828511/c24135ca63f2f86d4025935044828511','c24135ca63f2f86d4025935044828511','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-09 03:56:11',3,1,1,0,0,0,0,'1970-01-02 00:00:01','2017-01-08 04:56:11',1,'Jan','2017'),
 (3,1,'events upload 9-1-17-1.csv','events upload 9-1-17.csv',NULL,'event','csv','/smack_uci_uploads/imports/82a11621f38f19164e6cdf2856ab24fe/82a11621f38f19164e6cdf2856ab24fe','82a11621f38f19164e6cdf2856ab24fe','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-09 19:42:06',8,2,2,0,0,0,0,'1970-01-02 00:00:01','2017-01-09 08:42:06',1,'Jan','2017'),
 (4,1,'regulars upload 10-1-17 1-1.csv','regulars upload 10-1-17 1.csv',NULL,'regular','csv','/smack_uci_uploads/imports/e5b9415aa5c3e1b4a142a1aea5e37224/e5b9415aa5c3e1b4a142a1aea5e37224','e5b9415aa5c3e1b4a142a1aea5e37224','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-10 22:27:10',720,3,3,0,0,0,0,'1970-01-02 00:00:01','2017-01-10 11:27:10',1,'Jan','2017'),
 (5,1,'regulars upload 11-1-17-1.csv','regulars upload 11-1-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/7f7ca5bf9c227fe83d89a92844bbd732/7f7ca5bf9c227fe83d89a92844bbd732','7f7ca5bf9c227fe83d89a92844bbd732','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-11 22:08:50',8,6,6,0,0,0,0,'1970-01-02 00:00:01','2017-01-11 11:08:50',1,'Jan','2017'),
 (6,2,'events upload 11-1-17 3-2.csv','events upload 11-1-17 3.csv',NULL,'event','csv','/smack_uci_uploads/imports/0194fd84d9d901380b03820eb3ddc648/0194fd84d9d901380b03820eb3ddc648','0194fd84d9d901380b03820eb3ddc648','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-11 22:22:30',2,2,2,0,0,0,0,'1970-01-02 00:00:01','2017-01-11 11:22:30',1,'Jan','2017'),
 (7,1,'regulars upload 12-1-17-1.csv','regulars upload 12-1-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/902b0f32b8f199823963400f920bdbca/902b0f32b8f199823963400f920bdbca','902b0f32b8f199823963400f920bdbca','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-12 22:34:40',7,3,3,0,0,0,0,'1970-01-02 00:00:01','2017-01-12 11:34:40',1,'Jan','2017'),
 (8,2,'regulars upload 12-1-17-2.csv','regulars upload 12-1-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/fffaa6bbb655ad64c592fa37c27285d5/fffaa6bbb655ad64c592fa37c27285d5','fffaa6bbb655ad64c592fa37c27285d5','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-12 22:53:26',7,1,1,0,0,0,0,'1970-01-02 00:00:01','2017-01-12 11:53:26',1,'Jan','2017'),
 (9,3,'regulars upload 12-1-17-3.csv','regulars upload 12-1-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/2034bf6b4cbe05296b69cab1561ff242/2034bf6b4cbe05296b69cab1561ff242','2034bf6b4cbe05296b69cab1561ff242','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-12 22:55:23',7,7,7,0,0,0,0,'1970-01-02 00:00:01','2017-01-12 11:55:23',1,'Jan','2017'),
 (10,1,'regulars upload 14-1-17-1.csv','regulars upload 14-1-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/6c8400383d82bb9cc0ea7e0ed72c8354/6c8400383d82bb9cc0ea7e0ed72c8354','6c8400383d82bb9cc0ea7e0ed72c8354','1970-01-02 00:00:01',NULL,1,0,0,'2017-01-15 01:10:52',7,7,7,0,0,0,0,'1970-01-02 00:00:01','2017-01-14 02:10:52',1,'Jan','2017'),
 (11,2,'events 5-2-17-2.csv','events 5-2-17.csv',NULL,'event','csv','/smack_uci_uploads/imports/5ed4b5d9d2b5130fba95c9f783342765/5ed4b5d9d2b5130fba95c9f783342765','5ed4b5d9d2b5130fba95c9f783342765','1970-01-02 00:00:01',NULL,1,0,0,'2017-02-06 13:23:10',4,4,4,0,0,0,0,'1970-01-02 00:00:01','2017-02-06 02:23:10',1,'Feb','2017'),
 (12,2,'regulars 5-2-17-2.csv','regulars 5-2-17.csv',NULL,'regular','csv','/smack_uci_uploads/imports/9e8158f9b72c2dba0ec099efb8e132ab/9e8158f9b72c2dba0ec099efb8e132ab','9e8158f9b72c2dba0ec099efb8e132ab','1970-01-02 00:00:01',NULL,1,0,0,'2017-02-06 13:28:19',4,4,4,0,0,0,0,'1970-01-02 00:00:01','2017-02-06 02:28:19',1,'Feb','2017');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
