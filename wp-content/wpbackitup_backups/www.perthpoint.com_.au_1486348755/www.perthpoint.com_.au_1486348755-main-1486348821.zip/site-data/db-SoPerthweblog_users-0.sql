-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_users
-- Snapshot Table  : 1486348755_users
--
-- SQL    : SELECT * FROM SoPerthweblog_users LIMIT 0,10000
-- Offset : 0
-- Rows   : 2
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_users`
--
DROP TABLE  IF EXISTS `1486348755_users`;
CREATE TABLE `1486348755_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_users`
-- Number of rows: 2
--
INSERT INTO `1486348755_users` VALUES 
(1,'SoPerth_admin','$P$B2XfPii5b1A6I3OAnK4dz8LrtnV1YH/','soperth_admin','theshashiman@gmail.com','','2016-10-02 11:32:18','',0,'SoPerth_admin'),
 (2,'theperthpoint','$P$B4abvtGENdsJh2ypxfxAgHVFzF8ZMU1','theperthpoint','theperthpoint@gmail.com','','2016-10-31 04:23:58','1477887839:$P$BAUM.9.6rKt9wBVPv0yVj/U/L8/buQ/',0,'Perth Point');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
