-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : wp_ultimate_csv_importer_shortcodes_statusrel
-- Snapshot Table  : 1486348755x_wp_ultimate_csv_importer_shortcodes_statusrel
--
-- SQL    : SELECT * FROM wp_ultimate_csv_importer_shortcodes_statusrel LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755x_wp_ultimate_csv_importer_shortcodes_statusrel`
--
DROP TABLE  IF EXISTS `1486348755x_wp_ultimate_csv_importer_shortcodes_statusrel`;
CREATE TABLE `1486348755x_wp_ultimate_csv_importer_shortcodes_statusrel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventkey` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `shortcodes_count` int(20) DEFAULT NULL,
  `shortcode_mode` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `current_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_ultimate_csv_importer_shortcodes_statusrel`
-- Number of rows: 0
--
--
-- Data for table `wp_ultimate_csv_importer_shortcodes_statusrel`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
