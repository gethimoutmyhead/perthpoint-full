-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/06 on 02:40
--
-- Database : perthpoi_db
--
-- Backup   Table  : SoPerthweblog_term_taxonomy
-- Snapshot Table  : 1486348755_term_taxonomy
--
-- SQL    : SELECT * FROM SoPerthweblog_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1486348755_term_taxonomy`
--
DROP TABLE  IF EXISTS `1486348755_term_taxonomy`;
CREATE TABLE `1486348755_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `SoPerthweblog_term_taxonomy`
-- Number of rows: 14
--
INSERT INTO `1486348755_term_taxonomy` VALUES 
(1,1,'category','',0,2),
 (2,2,'nav_menu','',0,21),
 (3,3,'nav_menu','',0,3),
 (4,4,'category','',0,0),
 (5,5,'category','',0,0),
 (6,6,'category','',0,17),
 (8,8,'category','',0,2),
 (9,9,'category','',0,2),
 (10,10,'category','Any events happening to celebrate Christmas or Boxing Day in 2016',0,0),
 (12,12,'category','',0,5),
 (13,13,'category','',0,7),
 (14,14,'category','',0,10),
 (15,15,'category','',0,22),
 (16,16,'category','',0,11);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
