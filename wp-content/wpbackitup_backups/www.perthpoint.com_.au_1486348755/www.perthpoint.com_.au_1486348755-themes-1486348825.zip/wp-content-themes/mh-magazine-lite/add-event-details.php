<?php 
/* Template Name: add-event-details */
get_header();
?>

<div class="mh-wrapper clearfix">
    <div id="main-content" class="mh-content" role="main" itemprop="mainContentOfPage">
        <?php


            $homeURL = get_home_url();

    if(!empty($_SESSION['LoggedIn']) && !empty($_SESSION['Hostname']))
    {
        //successfully logged in
        
        $hostID = $_SESSION['HostID'];
        $hostName = $_SESSION['Hostname'];
        
        $userPod = pods('host', $hostID);
        $eventID = $_GET['eventID'];
        
        $eventPod = pods('event', $eventID);
        

            $postName = $eventPod->field('event_name') . ' @ ' . $eventPod->field('venue');
            $description = $eventPod->field('description');
            if (($eventPod->field('organiser.ID') == 0) || $eventPod->field('organiser.ID') == $hostID){
                $eventPod->save('organiser', $hostID);
                $eventPod->save('post_title', $postName);
                $eventPod->save('post_content', $description);
                echo 'Event submitted! We will review your event shortly';
                echo '<meta http-equiv="refresh" content="2;url='.$homeURL. '/members-area/ "';
            }else{
                echo 'you are not authorised to edit this event';
                echo '<meta http-equiv="refresh" content="2;url='.$homeURL. '/members-area/ "';
            }
        
        echo '<a class="memberButton" href="'.$homeURL.'/log-out">Log out here</a>';
    }else{
        //not logged in, re-direct to login page
        echo '<meta http-equiv="refresh" content="0;url='.$homeURL. '/host-login/>"';
    }


 

        ?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>