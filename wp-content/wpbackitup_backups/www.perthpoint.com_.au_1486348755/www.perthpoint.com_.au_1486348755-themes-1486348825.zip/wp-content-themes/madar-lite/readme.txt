-------------------------------------------------------
    Thank you for downloading Madar Lite theme!
-------------------------------------------------------

We have created a theme based on our necessities and experience, we will be glad if you like our WordPress Theme.
Our theme is Manually coded, so if you find any bug or errors or want to correct something, feel free to send us your feedback.
We want to go farther with our theme even better and we need downloaders support and feedbacks.

Don't forget to visit our website http://retina-theme.com

Thank you.

-------------------------------------------------------
    Copyright
-------------------------------------------------------

Madar Lite is a free WordPress full responsive theme with an option's panel, designed and developed by retina-theme team (www.retina-theme.com)
Feel free to use and modify Madar Lite theme as you like and need.
Madar Lite is distributed under the GPLv2 license( http://www.gnu.org/licenses/gpl-2.0.html ).
Extended or Pro version of Madar Lite http://retina-theme.com/prices



-------------------------------------------------------
    Installation
-------------------------------------------------------

1. Upload the "Madar Lite" folder to the "/wp-content/themes/" directory
or find in Appearance > Themes > Install theme, type �Madar Lite� in search field.
2. Activate the Theme through the 'Themes' menu in WordPress
3. Go to "Appearance" > Theme options
4. Config theme as you need from madarlite.



-------------------------------------------------------
    Translation
-------------------------------------------------------

The themes is ready for translation and already translated in Many languages.
We are open for users translations, translation can be included in new theme versions.
Default language is english.

-------------------------------------------------------
    Credits
-------------------------------------------------------
* jquery.Newsticker.js by Valentin Ledrapier(risq), License: GPLv2, License and download: https://github.com/risq/jquery-advanced-news-ticker
* jquery.cbpQTRotator.min.js v1.0.0 by Mary Lou Copyright 2013 � download: http://tympanus.net/codrops/2013/03/29/quotes-rotator/ , Licensed under the MIT license.
* jquery.nicescroll � http://nicescroll.areaaperta.com released under the MIT license.
* Flex Slider - Copyright (c) 2015 by WooThemes - https://github.com/woothemes/FlexSlider Licensed under MIT.
* Retina.js Copyright (c) 2013-2016 Axial, LLC, Ben Atkin https://github.com/imulus/retinajs  License: MIT, license and download: https://github.com/imulus/retinajs
* HTML5 Shiv v3.6 Copyright (c) 2014 Alexander Farkas (aFarkas).� License: GPLv2, license and download:https://github.com/aFarkas/html5shiv
* bonzo.js � Copyright 2012, Dustin Diaz License: MIT, license and download: https://github.com/ded/bonzo
* Modernizr � Made with love by Faruk, Paul, Alex, Ryan, Patrick, Stu, and Richard, download/license: https://github.com/modernizr/modernizr Licensed under MIT licensed.
* Gif/Png/Jpeg Files - Images in this theme carry the same license as the theme.
* Underscores - http://underscores.me/ Copyright: Automattic, automattic.com Licensed under GPL2 licenses.
* home.js/gotop.js/mainav.js - Licensed under GPL licenses.
* Font Awesome 4.3.0 by @davegandy - http://fontawesome.io - @fontawesome, License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)


=== Images ===
* musician country song banjo ukulele : CC0 by PublicDomainArchive
  https://pixabay.com/en/musician-country-song-banjo-ukulele-349790/ 


* taxi cab traffic cab new york : CC0 by unsplash 
  https://pixabay.com/en/taxi-cab-traffic-cab-new-york-381233/


* balloons helium balloons red balloon : CC0 by CalinFdp
  https://pixabay.com/en/balloons-helium-balloons-red-balloon-1331564/


* fennel vegetables fennel bulb food : CC0 by condesign
  https://pixabay.com/en/fennel-vegetables-fennel-bulb-food-1311673/


* ice cream cone ice sweet dessert : CC0 by unsplash
  https://pixabay.com/en/ice-cream-cone-ice-sweet-dessert-1209239/


* new york tourisme confiture : CC0 Public Domain
  https://pixabay.com/fr/new-york-tourisme-confiture-1587558/



  == CHANGE LOG ==

  = Version 1.6.0 =
* Customize Mobile Menu.
* Fix Display Errors.
* Change Theme Description.

= Version 1.5.9 =
* Add menu search icon.
* 

= Version 1.5.8 =
* fix error issues.

= Version 1.5.7 =
* fix content width to 1200px (was 900px).
* change the front page structure. 
* add Widget Area on The front page
* add to different widgets blocks
* add front page ADS banner.
* add sidebar ADS banners (300x250) (125x125)
* add customer header
* fix troubles in flexslider
* customize navigator buttons on flexslider
* add some different technical codes to enhance global performance

= Version 1.5.6 =
* fix some error bugs.

= Version 1.5.5 =
* Add welcome page.

= Version 1.5.3 =
* Fix color issues
* Fix some icons errors

= Version 1.5.2 =
* Fix Language bug

= Version 1.5.1 =
* Fix Responsive style bugs.
* Add Responsive Menu.
* Fix archive error.
* Fix jQuery bugs.

= Version 1.5 =
* Fix bad redirect urls.
* Fix customizer command for recent carousel.
* Add social header buttons.
* Fix random article button redirect.
* Remove a non used CSS rules.
* Update a new screenshot.