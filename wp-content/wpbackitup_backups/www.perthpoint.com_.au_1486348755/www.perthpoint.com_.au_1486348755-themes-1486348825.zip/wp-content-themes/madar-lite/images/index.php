<?php
	/* Silence is golden.
	   ---
	   http://greenpointlab.com/
	   http://themeforest.net/user/GreenPointLab */
?>