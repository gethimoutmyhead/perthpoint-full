<?php
	/* Silence is golden.
	   ---
	   https://retina-theme.com/
	   madar lite */
?>