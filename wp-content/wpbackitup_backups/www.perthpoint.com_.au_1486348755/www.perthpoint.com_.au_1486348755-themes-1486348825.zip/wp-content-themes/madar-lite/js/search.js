jQuery(document).ready(function(){
	   jQuery('.search-top').click(function(){
      jQuery('.search-form-top').toggle();
   });
});