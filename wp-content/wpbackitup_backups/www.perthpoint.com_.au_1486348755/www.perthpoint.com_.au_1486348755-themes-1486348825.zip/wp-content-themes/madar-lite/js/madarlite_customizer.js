jQuery(document).ready(function() {

	jQuery('.preview-notice').append('<a class="madarlite-upgrade-to-pro-button" href="https://retina-theme.com/madar-pro-responsive-multipurpose-retina-ready-wordpress-theme/" class="button" target="_blank">{pro}</a>'.replace('{pro}',madarLiteCustomizerObject.pro));

});